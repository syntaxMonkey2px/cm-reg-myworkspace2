# dynamic-width

Resizes width of any HTML element to its content. If element is a textbox, updates its width when the value changes.

## Example Usage

    // As simple as that!
    $('input').dynamicWidth();
